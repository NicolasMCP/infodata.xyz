sudo cp /home/my/Downloads/eclipse/eclipse.png /home/my/eclipse/jee-2019-09/eclipse.png

sudo echo -e '[Desktop Entry]\nVersion=1.0\nExec=/home/my/eclipse/jee-2019-09/eclipse/eclipse -vmargs -Duser.name="Seu Nome {@link seu@email.com}"\nIcon=/home/my/eclipse/jee-2019-09/eclipse.png\nType=Application\nTerminal=false\nComment=Eclipse IDE 2019-09 JEE\nName=Eclipse JEE 2019-09\nCategories=Development;IDE;Java;' | sudo tee /usr/share/applications/eclipse.jee.desktop
